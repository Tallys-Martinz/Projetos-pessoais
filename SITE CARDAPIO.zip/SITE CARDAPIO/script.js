// ===== SELETORES DE ELEMENTOS =====
const menuContainer = document.getElementById("menu-container"); // ⚠️ ID correto!
const cartBtn = document.getElementById("cart-btn");
const cartModal = document.getElementById("cart-modal");
const cartItemsContainer = document.getElementById("cart-items");
const cartTotal = document.getElementById("cart-total");
const checkoutBtn = document.getElementById("checkout-btn");
const closeModalBtn = document.getElementById("close-modal-btn");
const cartCounter = document.getElementById("cart-count");
const addressInput = document.getElementById("address");
const addressWarn = document.getElementById("address-warn");
const spanHora = document.getElementById("date-span");
const statusText = document.getElementById("status-text");
const clientNameInput = document.getElementById("client-name");
const nameWarn = document.getElementById("name-warn");
const paymentMethodInput = document.getElementById("payment-method");

let cart = [];

// ===== DADOS: PRODUTOS E DESCONTOS (localStorage) =====
function getProdutos() {
    try {
        const dados = localStorage.getItem('devburguer_menu');
        return dados ? JSON.parse(dados) : [];
    } catch { return []; }
}

function getDescontos() {
    try {
        const dados = localStorage.getItem('devburguer_descontos');
        return dados ? JSON.parse(dados) : [];
    } catch { return []; }
}

// Verifica se há desconto ativo para uma categoria
function getDescontoAtivo(categoria) {
    const hoje = new Date().toISOString().split('T')[0];
    return getDescontos().find(d => {
        if (!d.active) return false;
        if (hoje < d.startDate || hoje > d.endDate) return false;
        return d.applyTo === 'all' || d.applyTo === `category:${categoria}`;
    });
}

// Calcula preço final com desconto
function calcularPrecoFinal(price, desconto) {
    if (!desconto) return price;
    if (desconto.type === 'percent') {
        return price * (1 - desconto.value / 100);
    }
    return Math.max(0, price - desconto.value);
}

// ===== RENDERIZAÇÃO DINÂMICA DO MENU =====
function renderizarMenu() {
    if (!menuContainer) {
        console.warn('⚠️ Container #menu-container não encontrado no HTML');
        return;
    }
    
    const produtos = getProdutos().filter(p => p.active);
    
    // Fallback: se não houver produtos cadastrados, mostra mensagem
    if (!produtos.length) {
        menuContainer.innerHTML = `
            <div class="text-center py-16 px-4">
                <div class="text-6xl mb-4">🍔</div>
                <p class="text-gray-500 text-lg">Cardápio em atualização</p>
                <p class="text-gray-400 text-sm mt-2">Volte em breve para ver nossas delícias!</p>
            </div>`;
        return;
    }
    
    // Agrupa por categoria
    const categorias = {};
    produtos.forEach(p => {
        if (!categorias[p.categoria]) categorias[p.categoria] = [];
        categorias[p.categoria].push(p);
    });
    
    const labels = {
        hamburgueres: '🍔 Hamburgueres',
        bebidas: '🥤 Bebidas', 
        sobremesas: '🍰 Sobremesas',
        combos: '📦 Combos'
    };
    
    let html = '';
    
    // Cria seções por categoria
    Object.keys(labels).forEach(cat => {
        if (!categorias[cat]) return;
        
        html += `<div class="mx-auto max-w-7xl px-2 my-6" id="${cat}-section">
            <h2 class="font-bold text-3xl">${labels[cat]}</h2>
        </div>`;
        
        html += `<div class="grid grid-cols-1 md:grid-cols-2 gap-7 md:gap-10 mx-auto max-w-7xl px-2 mb-16" id="${cat}-grid"></div>`;
    });
    
    menuContainer.innerHTML = html;
    
    // Renderiza cards dos produtos
    Object.keys(categorias).forEach(cat => {
        const grid = document.getElementById(`${cat}-grid`);
        if (!grid) return;
        
        categorias[cat].forEach(p => {
            const desconto = getDescontoAtivo(cat);
            const precoFinal = calcularPrecoFinal(p.price, desconto);
            const temDesconto = desconto && precoFinal < p.price;
            
            grid.innerHTML += `
            <div class="flex gap-2 p-2 rounded-lg shadow-lg hover:shadow-2xl transition-shadow duration-300 relative group">
                ${temDesconto ? `
                    <span class="absolute top-2 right-2 bg-red-500 text-white text-xs font-bold px-2 py-1 rounded-full z-10">
                        -${desconto.type === 'percent' ? desconto.value + '%' : 'R$'+desconto.value}
                    </span>` : ''}
                
                <img src="${p.imagem || 'assets/hamb-1.png'}" 
                     alt="${p.nome}" 
                     class="w-24 h-24 sm:w-28 sm:h-28 rounded-md hover:scale-110 hover:-rotate-2 duration-300 object-cover">
                
                <div class="flex flex-col justify-between flex-grow">
                    <div>
                        <p class="font-bold text-gray-800">${p.nome}</p>
                        <p class="text-sm text-gray-500">Descrição do Produto</p>
                    </div>
                    
                    <div class="flex items-center gap-2 justify-between mt-2">
                        <div class="flex flex-col">
                            ${temDesconto ? `
                                <p class="text-xs text-gray-400 line-through">R$ ${p.price.toFixed(2)}</p>
                            ` : ''}
                            <p class="font-extrabold text-xl ${temDesconto ? 'text-red-600' : 'text-green-700'}">
                                R$ ${precoFinal.toFixed(2)}
                            </p>
                        </div>
                        
                        <button class="add-to-cart-btn bg-gray-900 hover:bg-gray-800 text-white px-5 py-2 rounded-lg 
                                     transition-all duration-300 hover:scale-110 active:scale-95 shadow-md"
                            data-id="${p.id}" 
                            data-name="${p.nome}" 
                            data-price="${precoFinal}" 
                            data-original="${p.price}">
                            <i class="fa fa-cart-plus"></i>
                        </button>
                    </div>
                </div>
            </div>`;
        });
    });
    
    console.log(`✅ Menu renderizado: ${produtos.length} produtos`);
}

// ===== STATUS DA LOJA =====
function checkOpen() {
    const statusManual = localStorage.getItem("statusLoja");
    if (statusManual === "fechado") return false;
    if (statusManual === "aberto") return true;
    const hora = new Date().getHours();
    return hora >= 18 && hora < 22;
}

function updateHeaderStatus() {
    if (!statusText || !spanHora) return;
    const isOpen = checkOpen();
    if (isOpen) {
        spanHora.classList.remove("bg-red-500");
        spanHora.classList.add("bg-green-600");
        statusText.innerText = "ABERTO ✅";
    } else {
        spanHora.classList.remove("bg-green-600");
        spanHora.classList.add("bg-red-500");
        statusText.innerText = "FECHADO 🔒";
    }
}

// ===== CARRINHO =====
if (cartBtn) {
    cartBtn.addEventListener("click", function () {
        updateHeaderStatus();
        cartModal.style.display = "flex";
        updateCartModal();
    });
}

if (cartModal) {
    cartModal.addEventListener("click", function (event) {
        if (event.target === cartModal) cartModal.style.display = "none";
    });
}

if (closeModalBtn) {
    closeModalBtn.addEventListener("click", function () {
        cartModal.style.display = "none";
    });
}

// Clique nos botões "Adicionar" (event delegation para elementos dinâmicos)
if (menuContainer) {
    menuContainer.addEventListener("click", function (event) {
        const btn = event.target.closest(".add-to-cart-btn");
        if (btn) {
            const name = btn.getAttribute("data-name");
            const price = parseFloat(btn.getAttribute("data-price"));
            if (name && !isNaN(price)) {
                addToCart(name, price);
            }
        }
    });
}

function addToCart(name, price) {
    if (!name || !price) return;
    
    const existingItem = cart.find(item => item.name === name);
    if (existingItem) {
        existingItem.quantity += 1;
    } else {
        cart.push({ name, price, quantity: 1 });
    }
    
    updateCartModal();
    
    if (typeof Toastify !== 'undefined') {
        Toastify({
            text: `"${name}" adicionado! 🛒`,
            duration: 3000,
            style: { background: "#16a34a", borderRadius: "8px", fontWeight: "500" }
        }).showToast();
    }
}

function updateCartModal() {
    if (!cartItemsContainer) return;
    
    cartItemsContainer.innerHTML = "";
    let total = 0;
    
    cart.forEach(item => {
        const cartItemElement = document.createElement("div");
        cartItemElement.classList.add("flex", "justify-between", "mb-4", "flex-col", "p-3", "bg-gray-50", "rounded-lg");
        
        cartItemElement.innerHTML = `
            <div class="flex items-center justify-between">
                <div>
                    <p class="font-medium text-gray-800">${item.name}</p>
                    <p class="text-sm text-gray-500">Qtd: ${item.quantity}</p> 
                    <p class="font-medium mt-1 text-green-700">R$ ${item.price.toFixed(2)}</p>
                </div>
                <button class="remove-from-cart-btn text-red-500 hover:text-red-700 font-medium text-sm px-3 py-1 
                             hover:bg-red-50 rounded transition" data-name="${item.name}">
                    Remover
                </button>
            </div>`;
        
        total += item.price * item.quantity;
        cartItemsContainer.appendChild(cartItemElement);
    });
    
    if (cartTotal) {
        cartTotal.textContent = total.toLocaleString("pt-BR", { 
            style: "currency", 
            currency: "BRL" 
        });
    }
    if (cartCounter) {
        cartCounter.innerHTML = cart.reduce((acc, item) => acc + item.quantity, 0);
    }
}

// Remover itens do carrinho
if (cartItemsContainer) {
    cartItemsContainer.addEventListener("click", function (event) {
        if (event.target.classList.contains("remove-from-cart-btn")) {
            const name = event.target.getAttribute("data-name");
            removeItemCart(name);
        }
    });
}

function removeItemCart(name) {
    if (!name) return;
    const index = cart.findIndex(item => item.name === name);
    
    if (index !== -1) {
        if (cart[index].quantity > 1) {
            cart[index].quantity -= 1;
        } else {
            cart.splice(index, 1);
        }
        updateCartModal();
    }
}

// ===== SALVAR PEDIDO =====
function salvarPedidoNoSistema(pedido) {
    try {
        let pedidos = JSON.parse(localStorage.getItem("pedidosRecebidos")) || [];
        pedidos.push(pedido);
        localStorage.setItem("pedidosRecebidos", JSON.stringify(pedidos));
        return true;
    } catch (error) {
        console.error("❌ Erro ao salvar pedido:", error);
        return false;
    }
}

// ===== FINALIZAR PEDIDO =====
if (checkoutBtn) {
    function enviarParaWhatsApp(pedido) {
        const numeroLoja = "5562985044345";
        const itensFormatados = pedido.itens.split(" | ").map(item => `• ${item.trim()}`).join("\n");
        
        const mensagem = `
*🛒 NOVO PEDIDO - ${pedido.id}*

👤 *Cliente:* ${pedido.cliente}
📍 *Endereço:* ${pedido.endereco}

🍔 *Itens:*
${itensFormatados}

💰 *Total:* ${pedido.total}
⏰ *Horário:* ${pedido.hora}
💳 *Pagamento:* ${pedido.pagamento}

_Obrigado pela preferência!_ 🙌
`.trim();
        
        const numeroLimpo = numeroLoja.replace(/\D/g, '');
        const url = `https://wa.me/${numeroLimpo}?text=${encodeURIComponent(mensagem)}`;
        
        const novaAba = window.open(url, "_blank");
        if (!novaAba) {
            alert("⚠️ Pop-up bloqueado! Permita pop-ups e tente novamente.");
        }
    }

    checkoutBtn.addEventListener("click", function () {
        // 🔒 Verifica se loja está aberta
        if (!checkOpen()) {
            if (typeof Toastify !== 'undefined') {
                Toastify({ 
                    text: "Ops! A loja está fechada no momento.", 
                    duration: 5000, 
                    style: { background: "#ef4444", borderRadius: "8px" }
                }).showToast();
            } else { 
                alert("Loja fechada no momento!"); 
            }
            return;
        }
        
        // 🔒 Carrinho não pode estar vazio
        if (cart.length === 0) {
            if (typeof Toastify !== 'undefined') {
                Toastify({ 
                    text: "Seu carrinho está vazio!", 
                    duration: 3000, 
                    style: { background: "#f59e0b" }
                }).showToast();
            }
            return;
        }
        
        // 🔒 Valida campos
        let hasError = false;
        
        if (clientNameInput && clientNameInput.value.trim() === "") {
            if (nameWarn) nameWarn.classList.remove("hidden");
            hasError = true;
        } else if (nameWarn) {
            nameWarn.classList.add("hidden");
        }
        
        if (addressInput && addressInput.value.trim() === "") {
            if (addressWarn) addressWarn.classList.remove("hidden");
            hasError = true;
        } else if (addressWarn) {
            addressWarn.classList.add("hidden");
        }
        
        if (paymentMethodInput && paymentMethodInput.value.trim() === "") {
            alert("Por favor, selecione uma forma de pagamento.");
            hasError = true;
        }
        
        if (hasError) {
            alert("Por favor, preencha todos os campos para continuar.");
            return;
        }
        
        // ✅ Cria e salva o pedido
        const cartItems = cart.map((item) => `${item.name} (${item.quantity})`).join(" | ");
        const pagamentoSelecionado = paymentMethodInput?.value || "Não informado";
        
        const novoPedido = {
            id: Math.floor(Math.random() * 9000) + 1000,
            cliente: clientNameInput.value.trim(),
            endereco: addressInput.value.trim(),
            itens: cartItems,
            total: cartTotal?.textContent || "R$ 0,00",
            hora: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
            pagamento: pagamentoSelecionado,
            status: "novo"
        };
        
        const salvo = salvarPedidoNoSistema(novoPedido);
        
        if (salvo) {
            if (typeof Toastify !== 'undefined') {
                Toastify({ 
                    text: "✅ Pedido enviado com sucesso!", 
                    duration: 4000, 
                    style: { background: "#16a34a" }
                }).showToast();
            }
            
            enviarParaWhatsApp(novoPedido);
            
            // 🧹 Limpa carrinho
            cart = [];
            if (clientNameInput) clientNameInput.value = "";
            if (addressInput) addressInput.value = "";
            updateCartModal();
            
            if (cartModal) cartModal.style.display = "none";
        } else {
            alert("Erro ao salvar pedido. Tente novamente.");
        }
    });
}

// ===== SYNC: Atualiza menu quando admin muda algo =====
window.addEventListener('storage', (e) => {
    if (e.key === 'statusLoja') {
        updateHeaderStatus();
    }
    if (e.key === 'devburguer_menu' || e.key === 'devburguer_descontos') {
        console.log('🔄 Cardápio atualizado, renderizando...');
        renderizarMenu();
    }
});

// ===== INICIALIZAÇÃO =====
function initClientPage() {
    updateHeaderStatus();
    renderizarMenu(); // ✅ Renderiza menu dinâmico
    if (cartCounter) cartCounter.innerHTML = cart.length;
    console.log("✅ Página do cliente inicializada");
}

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initClientPage);
} else {
    initClientPage();
}